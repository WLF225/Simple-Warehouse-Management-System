package com.example.project3.Classes;

public class AlertException extends RuntimeException {

    public AlertException(String message) {
        super(message);
    }
}
